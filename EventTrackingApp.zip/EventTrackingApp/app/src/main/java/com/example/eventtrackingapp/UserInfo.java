package com.example.eventtrackingapp;

public class UserInfo {

    private int id;
    private String username, userPassword;

    //List<EventInfo> events

    // Constructor
    public UserInfo(int id, String username, String userPassword) {
        this.id = id;
        this.username = username;
        this.userPassword = userPassword;
    }

    // non-parameter Constructor -unused
    public UserInfo() {
    }

    // Puts all variables into a single string
    @Override
    public String toString() {
        return "UserInfo{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", userPassword='" + userPassword + '\'' +
                '}';
    }

    /* Accessors and Mutators*/
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }
}
