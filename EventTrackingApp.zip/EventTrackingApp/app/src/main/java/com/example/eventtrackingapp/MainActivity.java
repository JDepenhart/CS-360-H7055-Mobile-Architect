package com.example.eventtrackingapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // Widgets
    Button btn_login, btn_addUser;
    EditText et_user, et_password;
    private int SMS_PERMISSION_CODE = 1;
    GlobalVars globalVars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Sets widget variables to their respective widgets
        btn_login = findViewById(R.id.btn_login);
        btn_addUser = findViewById(R.id.btn_addUser);
        et_user = findViewById(R.id.et_user);
        et_password = findViewById(R.id.et_password);

        btn_login.setEnabled(false);
        btn_addUser.setEnabled(false);

        et_user.addTextChangedListener(textWatcher);
        et_password.addTextChangedListener(textWatcher);

        // debug
        // deleteUsers();  // Used to delete all users for testing purposes, Keep commented out until in use.
        // startActivity(new Intent(MainActivity.this, EditEventActivity.class));

        /* Click Listeners */
        // login button
        btn_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
                List<UserInfo> users = dataBaseHelper.getUsers();

                String username = et_user.getText().toString();
                String password = et_password.getText().toString();

                for (UserInfo currentUser : users){
                    if (currentUser.getUsername().equals(username) && currentUser.getUserPassword().equals(password)) {
                        GlobalVars.setUsername(currentUser.getUsername());

                        startActivity(new Intent(MainActivity.this, EventActivity.class));
                    }
                }
            }
        });

        // create user button
        btn_addUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UserInfo userInfo;
                DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
                List<UserInfo> users = dataBaseHelper.getUsers();

                String username = et_user.getText().toString();
                boolean addUser = true;

                // Checks that user does not already exist
                for (UserInfo currentUser : users){
                    if (currentUser.getUsername().equals(username)) {
                        Toast.makeText(MainActivity.this, "User Already Exists", Toast.LENGTH_LONG).show();
                        addUser = false;
                    }
                }

                if (addUser){
                    userInfo = new UserInfo(-1, et_user.getText().toString(), et_password.getText().toString());

                    dataBaseHelper = new DataBaseHelper(MainActivity.this);
                    boolean success = dataBaseHelper.addUser(userInfo);

                    Toast.makeText(MainActivity.this, userInfo.toString(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(MainActivity.this, "Success = " + success, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    // Listener for nameText
    TextWatcher textWatcher = new TextWatcher() {
        // Activates when nameText updates
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String watchNameText = et_user.getText().toString().trim();
            String watchPassText = et_password.getText().toString().trim();

            btn_login.setEnabled(!watchNameText.isEmpty() && !watchPassText.isEmpty());
            btn_addUser.setEnabled(!watchNameText.isEmpty() && !watchPassText.isEmpty());
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            // Not in use
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // Not in use
        }
    };

    // Options menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.subject_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if (item.getItemId() == R.id.settings) {
            Intent intent = new Intent(MainActivity.this, SettingsActivity.class);
            startActivity(intent);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    // This is for an easy way to clear the full datatable of events. FOR DEBUGGING ONLY
    private void deleteUsers() {
        DataBaseHelper dataBaseHelper = new DataBaseHelper(MainActivity.this);
        List<UserInfo> users = dataBaseHelper.getUsers();

        for (UserInfo currentUser : users){
            dataBaseHelper.deleteUser(currentUser);
        }
    }
}