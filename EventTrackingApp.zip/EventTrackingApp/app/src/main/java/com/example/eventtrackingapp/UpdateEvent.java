package com.example.eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.UpdateAppearance;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.List;

public class UpdateEvent extends AppCompatActivity {

    EditText et_eventName, et_eventDesc;
    EditText et_month, et_day, et_year; // used to create date
    EditText et_hour, et_minute; // used to create date time
    Button btn_saveEvent, btn_deleteEvent, btn_cancel;

    String id, name, description, time, date, username;
    String formattedDate, formattedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_event);

        setUp();
        getIntentData();

        btn_saveEvent.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventDataBase eventDataBase = new EventDataBase(UpdateEvent.this);

                name = et_eventName.getText().toString().trim();
                description = et_eventDesc.getText().toString().trim();

                eventDataBase.updateEvent(id, name, description, getFormattedTime(), getFormattedDate(), GlobalVars.getUsername());

                startActivity(new Intent(UpdateEvent.this, EventActivity.class));
            }
        }));

        btn_deleteEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventDataBase eventDataBase = new EventDataBase(UpdateEvent.this);
                List<EventInfo> events = eventDataBase.getEvents();

                for (EventInfo currentEvent : events){
                    if(currentEvent.getId() == Integer.parseInt(id)){
                        eventDataBase.deleteEvent(currentEvent);
                    }

                    startActivity(new Intent(UpdateEvent.this, EventActivity.class));
                }
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UpdateEvent.this, EventActivity.class));
            }
        });
    }

    void getIntentData(){
        if(getIntent().hasExtra("id") && getIntent().hasExtra("name") &&
                getIntent().hasExtra("description") && getIntent().hasExtra("time") &&
                getIntent().hasExtra("date") && getIntent().hasExtra("username")) {

            id = getIntent().getStringExtra("id");
            name = getIntent().getStringExtra("name");
            description = getIntent().getStringExtra("description");
            time = getIntent().getStringExtra("time");
            date = getIntent().getStringExtra("date");
            username = getIntent().getStringExtra("username");

            et_eventName.setText(name);
            et_eventDesc.setText(description);
            splitTime(time);
            splitDate(date);
        }
    }

    void setUp(){
        et_eventName = findViewById(R.id.et_eventName2);
        et_eventDesc = findViewById(R.id.et_eventDesc2);

        et_month = findViewById(R.id.et_month2);
        et_day = findViewById(R.id.et_day2);
        et_year = findViewById(R.id.et_year2);

        et_hour = findViewById(R.id.et_hour2);
        et_minute = findViewById(R.id.et_minute2);

        et_eventName.addTextChangedListener(textWatcher);
        et_eventDesc.addTextChangedListener(textWatcher);
        et_hour.addTextChangedListener(textWatcher);
        et_minute.addTextChangedListener(textWatcher);
        et_month.addTextChangedListener(textWatcher);
        et_day.addTextChangedListener(textWatcher);
        et_year.addTextChangedListener(textWatcher);

        // Buttons
        btn_saveEvent = findViewById(R.id.btn_saveEvent2);
        btn_deleteEvent = findViewById(R.id.btn_deleteEvent2);
        btn_cancel = findViewById(R.id.btn_cancel2);

        btn_saveEvent.setEnabled(false);
    }

    // Formats the date based on the intent date
    void splitDate (String date){
        String[] items = date.split("/");

        et_month.setText(items[0]);
        et_day.setText(items[1]);
        et_year.setText(items[2]);
    }

    void splitTime (String time){
        String[] items = time.split(":");

        et_hour.setText(items[0]);
        et_minute.setText(items[1]);
    }

    // Gets text within the data text boxes and converts them into a single string for the date
    public String getFormattedDate() {
        formattedDate = et_month.getText().toString().trim() + "/" +
                et_day.getText().toString().trim() + "/" + et_year.getText().toString().trim();

        return formattedDate;
    }

    // Gets text within the data text boxes and converts them into a single string for the time
    public String getFormattedTime() {
        formattedTime = et_hour.getText().toString().trim() + ":" + et_minute.getText().toString().trim();

        return formattedTime;
    }

    // Listener for nameText
    TextWatcher textWatcher = new TextWatcher() {
        // Activates when nameText updates
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            String watchNameText = et_eventName.getText().toString().trim();
            String watchDescText = et_eventDesc.getText().toString().trim();

            String watchHourText = et_hour.getText().toString().trim();
            String watchMinuteText = et_minute.getText().toString().trim();

            String watchMonthText = et_month.getText().toString().trim();
            String watchDayText = et_day.getText().toString().trim();
            String watchYearText = et_year.getText().toString().trim();

            btn_saveEvent.setEnabled(!watchNameText.isEmpty() && !watchDescText.isEmpty() &&
                    !watchHourText.isEmpty() && !watchMinuteText.isEmpty() && !watchMonthText.isEmpty()
                    && !watchDayText.isEmpty() && !watchYearText.isEmpty());
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            // Not in use
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // Not in use
        }
    };
}