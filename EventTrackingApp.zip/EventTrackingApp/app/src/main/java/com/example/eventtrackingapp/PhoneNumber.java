package com.example.eventtrackingapp;

public class PhoneNumber {

    private int id;
    private String number;

    public PhoneNumber(int id, String number) {
        this.id = id;
        this.number = number;
    }

    @Override
    public String toString() {
        return "PhoneNumber{" +
                "id=" + id +
                ", number='" + number + '\'' +
                '}';
    }

    public int getId() {
        return id;
    }

    /* Accessors and Mutators*/
    public void setId(int id) {
        this.id = id;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}


