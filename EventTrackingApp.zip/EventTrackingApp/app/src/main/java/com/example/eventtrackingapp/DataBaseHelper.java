package com.example.eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DataBaseHelper extends SQLiteOpenHelper {

    /* This Database holds users */

    // Variables
    public static final String USER_TABLE = "USER_TABLE";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_USER_PASSWORD = "USER_PASSWORD";
    public static final String COLUMN_ID = "ID";

    // Constructor
    public DataBaseHelper(@Nullable Context context) {
        super(context, "EventTracking.db", null, 1);
    }

    // Runs upon the class creation
    @Override
    public void onCreate(SQLiteDatabase db) {
        // database creation statement
        String createTableStatement = "CREATE TABLE " + USER_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT, " + COLUMN_USER_PASSWORD + " TEXT)";

        db.execSQL(createTableStatement);
    }

    // This is called if database version number is changed
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    // Create operation
    public boolean addUser(UserInfo userInfo){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USERNAME, userInfo.getUsername());
        cv.put(COLUMN_USER_PASSWORD, userInfo.getUserPassword());

        long insert = db.insert(USER_TABLE, "EMPTY", cv);
        if (insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    // Read operation
    // Gets all users from the user table in the database
    public List<UserInfo> getUsers(){

        List<UserInfo> returnUsers = new ArrayList<>();
        // Read data from database
        String query = "SELECT * FROM " + USER_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            // loop through the query results and adds them to a list.
            do {
                int userId = cursor.getInt(0);
                String username = cursor.getString(1);
                String userPassword = cursor.getString(2);

                UserInfo newUser = new UserInfo(userId, username, userPassword);
                returnUsers.add(newUser);
            }while(cursor.moveToNext());
        }
        else {
            // failure. Nothing added to list
        }

        cursor.close();
        db.close();
        return  returnUsers;
    }

    // Unused in final app version
    // Delete operation
    public boolean deleteUser(UserInfo userInfo){

        SQLiteDatabase db = this.getWritableDatabase();
        String query = "DELETE FROM " + USER_TABLE + " WHERE " + COLUMN_ID + " = " + userInfo.getId();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            return true;
        }
        else {
            return false;
        }
    }
}