package com.example.eventtrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditEventActivity extends AppCompatActivity {

    EditText et_eventName, et_eventDesc;
    EditText et_month, et_day, et_year; // used to create date
    EditText et_hour, et_minute; // used to create date time
    Button btn_saveEvent, btn_cancel;

    String formattedDate, formattedTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event);

        setup();

        // Button listeners
        btn_saveEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventInfo eventInfo = new EventInfo(-1, et_eventName.getText().toString(),
                        et_eventDesc.getText().toString(), getFormattedTime(), getFormattedDate(), GlobalVars.getUsername());

                EventDataBase eventDataBase = new EventDataBase(EditEventActivity.this);

                boolean success = eventDataBase.addEvent(eventInfo);

                startActivity(new Intent(EditEventActivity.this, EventActivity.class));
            }
        });

        btn_cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EditEventActivity.this, EventActivity.class));
            }
        });
    }

    void setup(){
        // Name and Description
        et_eventName = findViewById(R.id.et_eventName);
        et_eventDesc = findViewById(R.id.et_eventDesc);

        et_hour = findViewById(R.id.et_hour);
        et_minute = findViewById(R.id.et_minute);

        et_month = findViewById(R.id.et_month);
        et_day = findViewById(R.id.et_day);
        et_year = findViewById(R.id.et_year);

        et_eventName.addTextChangedListener(textWatcher);
        et_eventDesc.addTextChangedListener(textWatcher);
        et_hour.addTextChangedListener(textWatcher);
        et_minute.addTextChangedListener(textWatcher);
        et_month.addTextChangedListener(textWatcher);
        et_day.addTextChangedListener(textWatcher);
        et_year.addTextChangedListener(textWatcher);

        // Buttons
        btn_saveEvent = findViewById(R.id.btn_saveEvent);
        btn_cancel = findViewById(R.id.btn_cancel);

        btn_saveEvent.setEnabled(false);
    }

    // Gets text within the data text boxes and converts them into a single string for the date
    public String getFormattedDate() {

        formattedDate = et_month.getText().toString().trim() + "/" +
                et_day.getText().toString().trim() + "/" + et_year.getText().toString().trim();

        return formattedDate;
    }

    // Gets text within the data text boxes and converts them into a single string for the time
    public String getFormattedTime() {

        formattedTime = et_hour.getText().toString().trim() + ":" + et_minute.getText().toString().trim();

        return formattedTime;
    }

    // Listener for nameText
    TextWatcher textWatcher = new TextWatcher() {
        // Activates when nameText updates
        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            String watchNameText = et_eventName.getText().toString().trim();
            String watchDescText = et_eventDesc.getText().toString().trim();

            String watchHourText = et_hour.getText().toString().trim();
            String watchMinuteText = et_minute.getText().toString().trim();

            String watchMonthText = et_month.getText().toString().trim();
            String watchDayText = et_day.getText().toString().trim();
            String watchYearText = et_year.getText().toString().trim();

            btn_saveEvent.setEnabled(!watchNameText.isEmpty() && !watchDescText.isEmpty() &&
                    !watchHourText.isEmpty() && !watchMinuteText.isEmpty() && !watchMonthText.isEmpty()
                    && !watchDayText.isEmpty() && !watchYearText.isEmpty());
        }

        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            // Not in use
        }

        @Override
        public void afterTextChanged(Editable editable) {
            // Not in use
        }
    };
}