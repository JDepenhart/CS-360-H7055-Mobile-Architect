package com.example.eventtrackingapp;

public class GlobalVars {

    private static String username;

    public static String getUsername() {
        return username;
    }

    public static void setUsername(String username) {
        GlobalVars.username = username;
    }
}
