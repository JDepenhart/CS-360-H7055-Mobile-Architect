package com.example.eventtrackingapp;

import java.util.Date;

public class EventInfo {

    private int id;
    private String eventName, eventDetails, eventTime, eventDate;

    /*
     * This will be taken from the current user after a successful login
     * it will be used to populate the recycler view with events
     * when an event is added or updated, it will save these values based on the current user that is logged in
     */
    private String username;

    /* Constructor */
    public EventInfo(int id, String eventName, String eventDetails, String eventTime, String eventDate, String username) {
        this.id = id;
        this.eventName = eventName;
        this.eventDetails = eventDetails;
        this.eventTime = eventTime;
        this.eventDate = eventDate;
        this.username = username;
    }

    // No Parameter constructor

    public EventInfo() {
    }

    // To String Method
    @Override
    public String toString() {
        return "EventInfo{" +
                "id=" + id +
                ", eventName='" + eventName + '\'' +
                ", eventDetails='" + eventDetails + '\'' +
                ", eventTime='" + eventTime + '\'' +
                ", eventDate='" + eventDate + '\'' +
                ", username='" + username + '\'' +
                '}';
    }

    /* Accessors and Mutator */

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public String getEventDetails() {
        return eventDetails;
    }

    public void setEventDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }

    public String getEventTime() {
        return eventTime;
    }

    public void setEventTime(String eventTime) {
        this.eventTime = eventTime;
    }

    public String getEventDate() {
        return eventDate;
    }

    public void setEventDate(String eventDate) {
        this.eventDate = eventDate;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
