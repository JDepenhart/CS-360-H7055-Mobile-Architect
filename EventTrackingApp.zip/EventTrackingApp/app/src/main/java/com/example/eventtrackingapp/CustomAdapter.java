package com.example.eventtrackingapp;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class CustomAdapter extends RecyclerView.Adapter<CustomViewHolder> {

    /* This is a custom adapter of the recycler view which displays events */

    private Context context;
    private List<EventInfo> eventInfoList;
    private CustomViewListener listener;
    Activity activity;

    public CustomAdapter(Activity activity, Context context, List<EventInfo> eventInfoList, CustomViewListener listener) {
        this.activity = activity;
        this.context = context;
        this.eventInfoList = eventInfoList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public CustomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new CustomViewHolder(LayoutInflater.from(context).inflate(R.layout.recycler_cell, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull CustomViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.setEventName(eventInfoList.get(position).getEventName());
        holder.setEventDesc(eventInfoList.get(position).getEventDetails());
        holder.setEventDate(eventInfoList.get(position).getEventDate());
        holder.setEventTime(eventInfoList.get(position).getEventTime());

        holder.getCardView().setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                listener.onItemClicked(eventInfoList.get(position));
            }
        });

    }

    @Override
    public int getItemCount() {
        return eventInfoList.size();
    }

    public Context getContext() {
        return context;
    }

    public Activity getActivity() {
        return activity;
    }
}
