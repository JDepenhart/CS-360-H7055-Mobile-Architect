package com.example.eventtrackingapp;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class CustomViewHolder extends RecyclerView.ViewHolder {

    /* This is a custom holder recycler view which displays events */

    private TextView eventName, eventDesc, eventDate, eventTime;
    private CardView cardView;

    public CustomViewHolder(@NonNull View itemView) {
        super(itemView);

        eventName = itemView.findViewById(R.id.tv_eventName);
        eventDesc = itemView.findViewById(R.id.tv_eventDesc);
        eventDate = itemView.findViewById(R.id.tv_eventDate);
        eventTime = itemView.findViewById(R.id.tv_eventTime);

        cardView = itemView.findViewById(R.id.cv_mainContainer);
    }

    public void setEventName(String name) {
        eventName.setText(name);
    }

    public void setEventDesc(String desc) {
        eventDesc.setText(desc);
    }

    public void setEventDate(String date) {
        eventDate.setText(date);
    }

    public void setEventTime(String time) {
        eventTime.setText(time);
    }

    public CardView getCardView() {
        return cardView;
    }
}
