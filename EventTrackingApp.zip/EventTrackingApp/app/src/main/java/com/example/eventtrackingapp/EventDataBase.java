package com.example.eventtrackingapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class EventDataBase extends SQLiteOpenHelper {

    public static final String EVENT_TABLE = "EVENT_TABLE";
    public static final String COLUMN_EVENT_NAME = "EVENT_NAME";
    public static final String COLUMN_EVENT_DESC = "EVENT_DESC";
    public static final String COLUMN_EVENT_TIME = "EVENT_TIME";
    public static final String COLUMN_EVENT_DATE = "EVENT_DATE";
    public static final String COLUMN_EVENT_USERNAME = "EVENT_USERNAME";
    public static final String COLUMN_ID = "ID";


    public EventDataBase(@Nullable Context context) {
        super(context, "event.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTableStatement = "CREATE TABLE " + EVENT_TABLE + " (" + COLUMN_ID +
                " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_EVENT_NAME + " TEXT, " +
                COLUMN_EVENT_DESC + " TEXT, " + COLUMN_EVENT_TIME + " TEXT, " + COLUMN_EVENT_DATE +
                " TEXT, " + COLUMN_EVENT_USERNAME + " TEXT)";

        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }

    public boolean addEvent(EventInfo eventInfo) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_NAME, eventInfo.getEventName());
        cv.put(COLUMN_EVENT_DESC, eventInfo.getEventDetails());
        cv.put(COLUMN_EVENT_TIME, eventInfo.getEventTime());
        cv.put(COLUMN_EVENT_DATE, eventInfo.getEventDate());
        cv.put(COLUMN_EVENT_USERNAME, eventInfo.getUsername());

        long insert = db.insert(EVENT_TABLE, "Empty", cv);

        if (insert == -1){
            return false;
        }
        else {
            return true;
        }
    }

    public List<EventInfo> getEvents() {

        List<EventInfo> returnList = new ArrayList<>();

        String query = "SELECT * FROM " + EVENT_TABLE;

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(query, null);

        if(cursor.moveToFirst()) {

            do {
                int eventID = cursor.getInt(0);
                String eventName = cursor.getString(1);
                String eventDesc = cursor.getString(2);
                String eventTime = cursor.getString(3);
                String eventDate = cursor.getString(4);
                String eventUsername = cursor.getString(5);

                EventInfo newEvent = new EventInfo(eventID, eventName, eventDesc, eventTime, eventDate, eventUsername);
                returnList.add(newEvent);

            } while (cursor.moveToNext());
        }
        else {
            // Nothing added to list
        }

        cursor.close();
        db.close();
        return returnList;
    }

    void updateEvent(String row_id, String name, String description, String time, String date, String username){

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_EVENT_NAME, name);
        cv.put(COLUMN_EVENT_DESC, description);
        cv.put(COLUMN_EVENT_TIME, time);
        cv.put(COLUMN_EVENT_DATE, date);
        cv.put(COLUMN_EVENT_USERNAME, username);

        long update = db.update(EVENT_TABLE, cv,  "ID=?", new String[]{row_id});
        if (update == -1){
            System.out.println("Failed to update");
        }
        else {
            System.out.println("Update Success");
        }
    }


    public boolean deleteEvent(EventInfo eventInfo){

        SQLiteDatabase db = this.getWritableDatabase();

        String query = "DELETE FROM " + EVENT_TABLE + " WHERE " + COLUMN_ID + " = " + eventInfo.getId();

        Cursor cursor = db.rawQuery(query, null);

        if (cursor.moveToFirst()) {
            return true;
        }
        else {
            return false;
        }
    }
}
