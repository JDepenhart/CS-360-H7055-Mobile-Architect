package com.example.eventtrackingapp;

public interface CustomViewListener {

    /* This is an interface to act as a view listener for the event Recycler view */

    void onItemClicked(EventInfo eventInfo);
}
