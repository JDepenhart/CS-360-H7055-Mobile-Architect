package com.example.eventtrackingapp;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.TelephonyManager;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class EventActivity extends AppCompatActivity implements CustomViewListener{

    Calendar calender = Calendar.getInstance();
    RecyclerView rv_eventView;
    CustomAdapter customAdapter;
    String currentUser = "" + GlobalVars.getUsername();

    ImageButton btn_addEvent;

    List<EventInfo> sortedList = new ArrayList<>();

    LocalDate currentDate = LocalDate.now();

    int month;
    int day;
    int year;

    int calMonth;
    int calDay;
    int calYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event);

        btn_addEvent = findViewById(R.id.btn_addEvent);

        displayEvents(); // Call before the permission if-statement!

        if (ContextCompat.checkSelfPermission(this,
                android.Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            checkEvents();
        }

        btn_addEvent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EventActivity.this, EditEventActivity.class));
            }
        });

    }

    private void displayEvents() {

        EventDataBase eventDataBase = new EventDataBase(EventActivity.this);
        List<EventInfo> unsortedList = eventDataBase.getEvents();

        rv_eventView = findViewById(R.id.rv_eventView);
        rv_eventView.setHasFixedSize(true);
        rv_eventView.setLayoutManager(new GridLayoutManager(this, 1));

        for (EventInfo currentEvent : unsortedList) {

            if(currentEvent.getUsername().equals(currentUser)){
                EventInfo newEvent = currentEvent;

                sortedList.add(newEvent);
            }
        }

        customAdapter = new CustomAdapter(EventActivity.this, this, sortedList, this);
        rv_eventView.setAdapter(customAdapter);
    }

    // Loops through events to check if there is an event that day. Then sends a notification
    private void checkEvents() {

        for (EventInfo currentEvent : sortedList) {

            String[] items = currentEvent.getEventDate().split("/");

            month = Integer.valueOf(items[0]);
            day = Integer.valueOf(items[1]);
            year = Integer.valueOf(items[2]);

            calMonth = currentDate.getMonthValue();
            calDay = currentDate.getDayOfMonth();
            calYear = currentDate.getYear();

            if(month == calMonth && day == calDay && year == calYear){
                Toast.makeText(this, "You have an Event today!", Toast.LENGTH_SHORT).show();

                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage("5551234567", null, "The event: "
                                + currentEvent.getEventName() + " is Today!", null, null);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 1){
            recreate();
        }
    }

    @Override
    public void onItemClicked(EventInfo eventInfo) {
        Toast.makeText(this, eventInfo.getEventName(), Toast.LENGTH_SHORT).show();

        Intent intent = new Intent(customAdapter.getContext(), UpdateEvent.class);

        intent.putExtra("id", String.valueOf(eventInfo.getId()));
        intent.putExtra("name", String.valueOf(eventInfo.getEventName()));
        intent.putExtra("description", String.valueOf(eventInfo.getEventDetails()));
        intent.putExtra("time", String.valueOf(eventInfo.getEventTime()));
        intent.putExtra("date", String.valueOf(eventInfo.getEventDate()));
        intent.putExtra("username", String.valueOf(eventInfo.getUsername()));

        customAdapter.getActivity().startActivityForResult(intent, 1);
    }

    // This is for an easy way to clear the full datatable of events. FOR DEBUGGING ONLY
    private void deleteEvents() {
        EventDataBase eventDataBase = new EventDataBase(EventActivity.this);
        List<EventInfo> events = eventDataBase.getEvents();

        for (EventInfo currentEvent : events){
            eventDataBase.deleteEvent(currentEvent);
        }
    }
}